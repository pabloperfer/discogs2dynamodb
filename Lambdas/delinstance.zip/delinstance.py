import logging
logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

try:
    import sys
    import discogs_client
    from discogs_client.exceptions import HTTPError
    import json
    import os
    import boto3

    from boto3.dynamodb.conditions import Key, Attr

    global mytoken; mytoken=os.environ["token"]
    global region; region=os.environ["curr_region"]
    global mytable; mytable=os.environ["table"]
    global user; user = os.environ["user"]

    global dynamodb; dynamodb = boto3.resource('dynamodb',region_name = region)
    global table; table = dynamodb.Table(mytable)

except Exception:
    log.exception("Lambda execution has failed")


def lambda_handler(event, context):
    try:
 
        insta=event["headers"]["instance_id"]
        release_id = get_release_id(insta)
        delfromdyn(insta)
        delfromdiscogs(insta,release_id)
    
        return send_response()

    except Exception:
        log.exception("Lambda execution has failed")
    
def get_release_id(insta):
    response = table.query(
    KeyConditionExpression=Key('instance_id').eq(int(insta)),
    ProjectionExpression='release_id')
    return (response["Items"][0]["release_id"])
    
    
def delfromdyn(insta):
    table.delete_item(
       Key={
            'instance_id': int(insta)
        }
    )


def delfromdiscogs(insta,release_id):
    dc = discogs_client.Client('ExampleApplication/0.1', user_token=mytoken)
    url=f"https://api.discogs.com/users/{user}/collection/folders/0/releases/{release_id}/instances/{insta}"
    p=dc._delete(url)


def send_response():

    response = {
        'statusCode': 0,
        'headers': {'Your-custom-header':'custom-header-value'},
        'body': ''
        }
    statusCode="";headers={}
    response["statusCode"] = 200
    response["headers"] =  {"x-custom-header" : "and table synced"}
    response["body"] = "record deleted"
    return response

