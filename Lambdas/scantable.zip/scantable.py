import logging
import json
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import boto3
import os


logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def lambda_handler(event, context):
    try:
        table=os.environ["table"]   
        region=os.environ["curr_region"]

        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table)

        scan = table.scan(IndexName='bandGSI',Limit=50000,Select='ALL_ATTRIBUTES',ConsistentRead=False)
        
        items=scan['Items']
        
        
        x = json.dumps(items,default=handle_decimal_type)  #### I serialize the "items" dictionaries

        print(x)

 
        response={}
        statusCode="";headers={}
        response["statusCode"] = 200
        response["headers"] =  {"x-custom-header" : "search done"}
        response["body"] = x
        return response
    
    except Exception:
        log.exception("Lambda execution has failed")
        
        
def handle_decimal_type(obj):
  if isinstance(obj, Decimal):
      if float(obj).is_integer():
         return int(obj)
      else:
         return float(obj)
  raise TypeError
