import logging
logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

try:
    import json
    import boto3
    import os
    import sys
    import time
    import threading
    import discogs_client
    from botocore.vendored import requests
    from discogs_client.exceptions import HTTPError
    from collections import defaultdict
    from queue import Queue

    global s;s = 1
    global mytoken; mytoken=os.environ["token"]
    global table ; table=os.environ["table"]   
    global user; user = os.environ["user"]
    global d; d = defaultdict(dict)
    global region; region=os.environ["curr_region"]

except Exception:
    log.exception("Lambda execution has failed")

def lambda_handler(event, context):
    try:
    
        global rele; rele = event["headers"]["release_id"]
        dc = discogs_client.Client('ExampleApplication/0.1', user_token=mytoken)
        url2=f"https://api.discogs.com/users/{user}/collection/folders/1/releases/{rele}"
        p=dc._post(url2,"data")
    
        time.sleep(1)
        sync_added_record()
    
        d.clear()
    
        return send_response()

    except Exception:
        log.exception("Lambda execution has failed")
    
    
def sync_added_record():
    url="https://api.discogs.com/users/"+user+"/collection/folders/0/releases"
   
    r = requests.get(url, mytoken)
    response_dict = r.json()
    
    total_items=(response_dict["pagination"]["items"])
    totalpages=(response_dict["pagination"]["pages"])
    pagination=((response_dict["pagination"]["per_page"]))
    
    for i in range(len(response_dict["releases"])):
        if rele == response_dict["releases"][i]["basic_information"]["id"]:
            d[i]["instance_id"] = (response_dict["releases"][i]["instance_id"])
            d[i]["band"] = (response_dict["releases"][i]["basic_information"]["artists"][0]["name"])
            d[i]["label"] = (response_dict["releases"][i]["basic_information"]["labels"][0]["name"])
            d[i]["release_id"] = (response_dict["releases"][i]["basic_information"]["id"])
            d[i]["title"] = (response_dict["releases"][i]["basic_information"]["title"])
            d[i]["format"] = (response_dict["releases"][i]["basic_information"]["formats"][0]["descriptions"][0])
            d[i]["year"] = (response_dict["releases"][i]["basic_information"]["year"])

    if totalpages > 1:
        urls = []
        for i in range(2,totalpages+1):
            urls.append("https://api.discogs.com/users/"+user+"/collection/folders/0/releases?per_page=50&page=" + str(i))
        Create_threads(urls,d)    ### we fill the dictioanry with the records with the same release_id  using threads ,one per page, to downlaod and parse all the pages
    
    InjectinDDB(d)
    

class Downloader(threading.Thread):
    def __init__(self, queue,d):   ###overwrite the init to accept a queue object
        """Initialize the thread"""
        threading.Thread.__init__(self)
        self.queue = queue
        self.d = d

    def run(self):
        """Run the thread"""
        while True:
            # gets the url from the queue, waits until it gets it
            url = self.queue.get()
            # download the release
            self.download_release(url,self.d)
            # send a signal to the queue that the job is done
            self.queue.task_done()

    def download_release(self,url,d):
        global s
        r = requests.get(url, mytoken)
        response_dict = r.json()
        for x in range(len(response_dict["releases"])):
            if int(rele) == response_dict["releases"][x]["basic_information"]["id"] :
                d[str(s) +"-"+ str(x)]["instance_id"] = (response_dict["releases"][x]["instance_id"])
                d[str(s) +"-"+ str(x)]["band"] = (response_dict["releases"][x]["basic_information"]["artists"][0]["name"])
                d[str(s) +"-"+ str(x)]["label"] = (response_dict["releases"][x]["basic_information"]["labels"][0]["name"])
                d[str(s) +"-"+ str(x)]["release_id"] = (response_dict["releases"][x]["basic_information"]["id"])
                d[str(s) +"-"+ str(x)]["title"] = (response_dict["releases"][x]["basic_information"]["title"])
                d[str(s) +"-"+ str(x)]["format"] = (response_dict["releases"][x]["basic_information"]["formats"][0]["descriptions"][0])
                d[str(s) +"-"+ str(x)]["year"] = (response_dict["releases"][x]["basic_information"]["year"])
        s+=1

def Create_threads(urls, d):
    queue=Queue()   ###we create an object of class queue
    #we create a thread pool with a queue for each
    for i in range(len(urls)):
        th= Downloader(queue,d)   ###we create an object of class downloader, a thread object with its queue
        th.setDaemon(True)
        th.start()
    #we load up the queue with the urls
    for url in urls:
        queue.put(url)

    #wait for the queue threads to do their processing via the join method.
    queue.join()


def InjectinDDB(d):
    client = boto3.client('dynamodb',region_name = region)
    for key,value in d.items():
        response = client.put_item(TableName=table,Item={
               'instance_id': 
                    { 
                   'N': str((value["instance_id"])), 
                    },
                  'band': {
                      'S': (value["band"]),},
                  'record_label': {'S': (value["label"]),},
                  'year': {'N': str((value["year"])),},
                  'title': {'S': (value["title"]),},
                  'format': { 'S': (value["format"]),},
                  'release_id': {'N': str(value["release_id"]), },},)
        time.sleep(0.1)
    

def send_response():

    response = {
        'statusCode': 0,
        'headers': {'Your-custom-header':'custom-header-value'},
        'body': ''
        }
    statusCode="";headers={}
    response["statusCode"] = 200
    response["headers"] =  {"x-custom-header" : "record added"}
    response["body"] = "and Table synced!!"
    return response

